pjass 07.11.2007 (v 1.0k)
A lightweight and fast Jass2 parser for bison/yacc
by Rudi Cilibrasi
Sun Jun  8 00:51:53 CEST 2003
thanks to Jeff Pang for the handy documentation that this was based
on at http://jass.sourceforge.net/
Released under the BSD license

To use this program, list the files you would like to parse in order.
If you would like to parse from standard input (the keyboard), then
use - as an argument.  If you supply no arguments to pjass, it will
parse the console standard input by default.

To test this program:
pjass common.j common.ai Blizzard.j

You can find news about this program and updates at
http://www.wc3campaigns.net/showthread.php?t=75239 and
http://jass.sourceforge.net/

Please send comments to
Rudi Cilibrasi
cilibrar@ofb.net
