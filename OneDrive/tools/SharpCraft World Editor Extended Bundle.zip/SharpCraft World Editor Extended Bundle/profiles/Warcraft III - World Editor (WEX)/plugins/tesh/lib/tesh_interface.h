#ifndef TESH_INTERFACE_H
#define TESH_INTERFACE_H

#ifdef EXPORT_TESH_INTERFACE_FUNCTIONS
#    define TESH_API __declspec(dllexport)
#else
#    define TESH_API __declspec(dllimport)
#endif

extern "C"
{
	/**
	* @brief		This function allows to set the search string for the trigger editor window programmatically.
	*
	* Effectivly, this function just changes the content in the "trigger_editor_name.ini" file. It overwrites
	* the content of this file with the string provided as parameter. The file itself has to be located in
	* its standard location which is ".../tesh/config/trigger_editor_name.ini". Here, ... denotes the path
	* to your TESH installation. IMPORTANT: This function should be called directly after loading tesh.dll.
	*
	* @param name	The search name used by TESH to identify the trigger editor window. Has to match exactly to the actual window name.
	*
	* @retval 0		No error: Search name was successfully changed.
	* @retval 1		Module error: The dll module was 0, which usually happens if the dll was not loaded.
	* @retval 2		File error: The "config" directory does not exist.
	* @retval 3		Filesystem error: General filesystem exception caught.
	* @retval 4		File IO error: Writing to the text file caused an exception.
	* @retval 5		Memory error: Memory allocation has thrown a bad_alloc exception.
	* @retval 6		Unknown error: Some unexcepted error happened.
	*/
	TESH_API int SetTeshTriggerEditorWindowSearchName(const char *name);
}

#endif
